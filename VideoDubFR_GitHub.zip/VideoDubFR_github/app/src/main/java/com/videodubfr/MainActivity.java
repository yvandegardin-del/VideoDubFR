package com.videodubfr;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private View dropZone, cardPreview, layoutUrl, cardProgress, cardResult;
    private Button btnUrl, btnOk, btnStart, btnSave, btnShare, btnReset;
    private EditText etUrl;
    private TextView tvSource, tvStatus, tvPercent;
    private ProgressBar progressBar;

    private Uri selectedUri = null;
    private String selectedUrl = null;
    private File outputFile = null;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    private static final int PICK_VIDEO = 1;
    private static final int REQ_PERM   = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        setupListeners();
        handleSharedIntent(getIntent());
    }

    private void bindViews() {
        dropZone     = findViewById(R.id.dropZone);
        cardPreview  = findViewById(R.id.cardPreview);
        layoutUrl    = findViewById(R.id.layoutUrl);
        cardProgress = findViewById(R.id.cardProgress);
        cardResult   = findViewById(R.id.cardResult);
        btnUrl       = findViewById(R.id.btnUrl);
        btnOk        = findViewById(R.id.btnOk);
        btnStart     = findViewById(R.id.btnStart);
        btnSave      = findViewById(R.id.btnSave);
        btnShare     = findViewById(R.id.btnShare);
        btnReset     = findViewById(R.id.btnReset);
        etUrl        = findViewById(R.id.etUrl);
        tvSource     = findViewById(R.id.tvSource);
        tvStatus     = findViewById(R.id.tvStatus);
        tvPercent    = findViewById(R.id.tvPercent);
        progressBar  = findViewById(R.id.progressBar);
    }

    private void setupListeners() {
        dropZone.setOnClickListener(v -> checkPermAndPick());

        btnUrl.setOnClickListener(v ->
            layoutUrl.setVisibility(
                layoutUrl.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE)
        );

        btnOk.setOnClickListener(v -> {
            String url = etUrl.getText().toString().trim();
            if (url.startsWith("http://") || url.startsWith("https://")) {
                selectedUrl = url;
                selectedUri = null;
                showSource("\uD83D\uDD17 " + url);
                layoutUrl.setVisibility(View.GONE);
            } else {
                Toast.makeText(this, "URL invalide", Toast.LENGTH_SHORT).show();
            }
        });

        btnStart.setOnClickListener(v -> startDubbing());
        btnSave.setOnClickListener(v -> saveToGallery());
        btnShare.setOnClickListener(v -> shareVideo());
        btnReset.setOnClickListener(v -> resetUI());
    }

    private void checkPermAndPick() {
        String perm = Build.VERSION.SDK_INT >= 33
            ? Manifest.permission.READ_MEDIA_VIDEO
            : Manifest.permission.READ_EXTERNAL_STORAGE;

        if (ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED) {
            openPicker();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{perm}, REQ_PERM);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_PERM && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED)
            openPicker();
    }

    private void openPicker() {
        Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
        i.setType("video/*");
        startActivityForResult(i, PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == PICK_VIDEO && res == RESULT_OK && data != null && data.getData() != null) {
            selectedUri = data.getData();
            selectedUrl = null;
            showSource("\uD83D\uDCF9 " + UriHelper.getName(this, selectedUri));
        }
    }

    private void handleSharedIntent(Intent intent) {
        if (intent != null && Intent.ACTION_SEND.equals(intent.getAction())) {
            Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (uri != null) {
                selectedUri = uri;
                showSource("\uD83D\uDCF9 " + UriHelper.getName(this, uri));
            }
        }
    }

    private void showSource(String label) {
        tvSource.setText(label);
        cardPreview.setVisibility(View.VISIBLE);
        btnStart.setEnabled(true);
    }

    // ── Pipeline ──────────────────────────────────────────────────────────────
    private void startDubbing() {
        btnStart.setEnabled(false);
        cardProgress.setVisibility(View.VISIBLE);
        cardResult.setVisibility(View.GONE);

        DubbingPipeline pipeline = new DubbingPipeline(this, new DubbingPipeline.Callback() {
            @Override public void onProgress(int pct, String msg) {
                uiHandler.post(() -> {
                    progressBar.setProgress(pct);
                    tvPercent.setText(pct + "%");
                    tvStatus.setText(msg);
                });
            }
            @Override public void onSuccess(File result) {
                outputFile = result;
                uiHandler.post(() -> {
                    cardProgress.setVisibility(View.GONE);
                    cardResult.setVisibility(View.VISIBLE);
                    btnStart.setEnabled(true);
                });
            }
            @Override public void onError(String err) {
                uiHandler.post(() -> {
                    cardProgress.setVisibility(View.GONE);
                    btnStart.setEnabled(true);
                    Toast.makeText(MainActivity.this, "❌ " + err, Toast.LENGTH_LONG).show();
                });
            }
        });

        executor.execute(() -> pipeline.run(selectedUri, selectedUrl));
    }

    private void saveToGallery() {
        if (outputFile == null) return;
        try {
            File dir  = android.os.Environment.getExternalStoragePublicDirectory(
                            android.os.Environment.DIRECTORY_MOVIES);
            dir.mkdirs();
            File dest = new File(dir, "VideoDubFR_" + System.currentTimeMillis() + ".mp4");
            UriHelper.copy(outputFile, dest);
            // Tell gallery scanner
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
                                     Uri.fromFile(dest)));
            Toast.makeText(this, "✅ Sauvegardé dans Vidéos/Films !", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Erreur : " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void shareVideo() {
        if (outputFile == null) return;
        Uri uri = FileProvider.getUriForFile(this,
            getPackageName() + ".fileprovider", outputFile);
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("video/mp4");
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(share, "Partager"));
    }

    private void resetUI() {
        selectedUri = null; selectedUrl = null; outputFile = null;
        cardPreview.setVisibility(View.GONE);
        cardProgress.setVisibility(View.GONE);
        cardResult.setVisibility(View.GONE);
        layoutUrl.setVisibility(View.GONE);
        etUrl.setText("");
        btnStart.setEnabled(false);
        progressBar.setProgress(0);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
