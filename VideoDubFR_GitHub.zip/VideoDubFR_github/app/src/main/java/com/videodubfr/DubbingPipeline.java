package com.videodubfr;

import android.content.Context;
import android.media.*;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import okhttp3.*;
import org.json.JSONObject;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * 100% FREE dubbing pipeline — no API key needed:
 *
 *  1. Prepare video  (URI copy or URL download)
 *  2. Extract audio  (MediaExtractor + MediaCodec → raw PCM → WAV)
 *  3. Transcribe     (Whisper via free public instance on Hugging Face)
 *  4. Translate → FR (MyMemory free API, no key, 5 000 chars/day)
 *  5. French TTS     (Android built-in TTS, female FR voice, offline)
 *  6. Merge          (MediaMuxer: original video track + TTS audio track)
 */
public class DubbingPipeline {

    public interface Callback {
        void onProgress(int pct, String msg);
        void onSuccess(File result);
        void onError(String err);
    }

    private final Context ctx;
    private final Callback cb;
    private final OkHttpClient http;

    // ── Free Whisper endpoints (Hugging Face Spaces — no key required) ────────
    // These are community-hosted inference endpoints; if one is busy another is tried.
    private static final String[] WHISPER_URLS = {
        "https://openai-whisper.hf.space/run/predict",
        "https://sanchit-gandhi-whisper-large-v2.hf.space/run/predict",
        "https://whisper-webui.hf.space/run/predict"
    };

    // ── MyMemory translation API (free, no key) ───────────────────────────────
    private static final String MYMEMORY = "https://api.mymemory.translated.net/get";

    // ── LibreTranslate public instances ──────────────────────────────────────
    private static final String[] LIBRE = {
        "https://translate.argosopentech.com/translate",
        "https://libretranslate.de/translate",
        "https://libretranslate.com/translate"
    };

    public DubbingPipeline(Context ctx, Callback cb) {
        this.ctx = ctx;
        this.cb  = cb;
        this.http = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(180, TimeUnit.SECONDS)
            .writeTimeout(60,  TimeUnit.SECONDS)
            .build();
    }

    public void run(Uri videoUri, String videoUrl) {
        try {
            step(5,  "📥 Préparation de la vidéo...");
            File video = prepareVideo(videoUri, videoUrl);

            step(18, "🔊 Extraction de l'audio...");
            File wav = extractAudio(video);

            step(35, "✍️ Transcription (Whisper gratuit)...");
            String text = transcribe(wav);
            if (text.isEmpty()) throw new Exception("Transcription vide — qualité audio insuffisante ?");

            step(55, "🇫🇷 Traduction en français...");
            String fr = translate(text);
            if (fr.isEmpty()) fr = text;

            step(70, "🎙️ Génération de la voix française...");
            File ttsWav = generateVoice(fr);

            step(85, "🎬 Assemblage de la vidéo finale...");
            File out = merge(video, ttsWav);

            step(100, "✅ Terminé !");
            cb.onSuccess(out);

        } catch (Exception e) {
            cb.onError(e.getMessage() != null ? e.getMessage() : e.toString());
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    // 1. PREPARE VIDEO
    // ────────────────────────────────────────────────────────────────────────
    private File prepareVideo(Uri uri, String url) throws Exception {
        File out = tmp("input", ".mp4");
        if (uri != null) {
            try (InputStream in = ctx.getContentResolver().openInputStream(uri);
                 FileOutputStream fos = new FileOutputStream(out)) {
                if (in == null) throw new Exception("Impossible d'ouvrir la vidéo");
                pipe(in, fos);
            }
        } else if (url != null) {
            Request req = new Request.Builder().url(url)
                .header("User-Agent", "Mozilla/5.0").build();
            try (Response resp = http.newCall(req).execute()) {
                if (!resp.isSuccessful()) throw new Exception("Téléchargement échoué : HTTP " + resp.code());
                try (FileOutputStream fos = new FileOutputStream(out)) {
                    pipe(resp.body().byteStream(), fos);
                }
            }
        } else throw new Exception("Aucune source vidéo sélectionnée");
        return out;
    }

    // ────────────────────────────────────────────────────────────────────────
    // 2. EXTRACT AUDIO → WAV 16kHz mono  (pure Android API, no ffmpeg)
    // ────────────────────────────────────────────────────────────────────────
    private File extractAudio(File video) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        ex.setDataSource(video.getAbsolutePath());

        int track = -1;
        MediaFormat fmt = null;
        for (int i = 0; i < ex.getTrackCount(); i++) {
            MediaFormat f = ex.getTrackFormat(i);
            if (f.getString(MediaFormat.KEY_MIME).startsWith("audio/")) {
                track = i; fmt = f; break;
            }
        }
        if (track < 0) throw new Exception("Aucune piste audio dans la vidéo");

        ex.selectTrack(track);
        MediaCodec dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
        dec.configure(fmt, null, null, 0);
        dec.start();

        ByteArrayOutputStream pcm = new ByteArrayOutputStream();
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean eos = false;

        while (!eos) {
            int idx = dec.dequeueInputBuffer(10_000);
            if (idx >= 0) {
                ByteBuffer buf = dec.getInputBuffer(idx);
                int n = ex.readSampleData(buf, 0);
                if (n < 0) {
                    dec.queueInputBuffer(idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                    eos = true;
                } else {
                    dec.queueInputBuffer(idx, 0, n, ex.getSampleTime(), 0);
                    ex.advance();
                }
            }
            int out = dec.dequeueOutputBuffer(info, 10_000);
            if (out >= 0) {
                ByteBuffer buf = dec.getOutputBuffer(out);
                byte[] chunk = new byte[info.size];
                buf.get(chunk);
                pcm.write(chunk);
                dec.releaseOutputBuffer(out, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
            }
        }
        dec.stop(); dec.release(); ex.release();

        int sr  = fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)   ? fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)   : 44100;
        int ch  = fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)  ? fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)  : 2;

        File wav = tmp("audio", ".wav");
        writeWav(wav, pcm.toByteArray(), sr, ch);
        return wav;
    }

    private void writeWav(File f, byte[] pcm, int sr, int ch) throws IOException {
        int br = sr * ch * 2;
        try (DataOutputStream d = new DataOutputStream(new FileOutputStream(f))) {
            d.writeBytes("RIFF"); leInt(d, 36 + pcm.length);
            d.writeBytes("WAVEfmt "); leInt(d, 16); leShort(d, (short)1);
            leShort(d, (short)ch); leInt(d, sr); leInt(d, br);
            leShort(d, (short)(ch*2)); leShort(d, (short)16);
            d.writeBytes("data"); leInt(d, pcm.length); d.write(pcm);
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    // 3. TRANSCRIBE — free Hugging Face Whisper Spaces
    // ────────────────────────────────────────────────────────────────────────
    private String transcribe(File wav) throws Exception {
        byte[] audio = readBytes(wav);

        // Hugging Face Gradio API format
        // encode audio to base64 data URI for Gradio
        String b64 = android.util.Base64.encodeToString(audio, android.util.Base64.NO_WRAP);
        String dataUri = "data:audio/wav;base64," + b64;

        JSONObject payload = new JSONObject();
        payload.put("data", new org.json.JSONArray().put(dataUri).put("transcribe"));

        for (String url : WHISPER_URLS) {
            try {
                String resp = post(url, payload.toString(), "application/json");
                JSONObject json = new JSONObject(resp);
                org.json.JSONArray data = json.optJSONArray("data");
                if (data != null && data.length() > 0) {
                    String result = data.getString(0).trim();
                    if (!result.isEmpty()) return result;
                }
            } catch (Exception ignored) {}
        }

        throw new Exception("Tous les serveurs Whisper gratuits sont occupés.\n" +
            "Réessayez dans quelques minutes ou connectez-vous au Wi-Fi.");
    }

    // ────────────────────────────────────────────────────────────────────────
    // 4. TRANSLATE → FRENCH — MyMemory (free, no key, 5k chars/day)
    //    + LibreTranslate fallbacks
    // ────────────────────────────────────────────────────────────────────────
    private String translate(String text) throws Exception {
        if (text.length() > 4500) return translateChunked(text);

        // MyMemory (most reliable free option)
        try {
            String enc = java.net.URLEncoder.encode(text, "UTF-8");
            String url = MYMEMORY + "?q=" + enc + "&langpair=auto|fr&de=videodubfr@user.com";
            Request req = new Request.Builder().url(url).build();
            try (Response resp = http.newCall(req).execute()) {
                if (resp.isSuccessful()) {
                    JSONObject json = new JSONObject(resp.body().string());
                    String tr = json.getJSONObject("responseData").getString("translatedText").trim();
                    if (!tr.isEmpty() && !tr.equals("INVALID LANGUAGE PAIR")) return tr;
                }
            }
        } catch (Exception ignored) {}

        // LibreTranslate fallbacks
        for (String url : LIBRE) {
            try {
                JSONObject body = new JSONObject();
                body.put("q", text); body.put("source", "auto"); body.put("target", "fr");
                String resp = post(url, body.toString(), "application/json");
                String tr = new JSONObject(resp).getString("translatedText").trim();
                if (!tr.isEmpty()) return tr;
            } catch (Exception ignored) {}
        }

        // Return original if all fail (better than crashing)
        return text;
    }

    private String translateChunked(String text) throws Exception {
        String[] sents = text.split("(?<=[.!?])\\s+");
        StringBuilder chunk = new StringBuilder(), result = new StringBuilder();
        for (String s : sents) {
            if (chunk.length() + s.length() > 4000) {
                result.append(translate(chunk.toString().trim())).append(" ");
                chunk = new StringBuilder();
            }
            chunk.append(s).append(" ");
        }
        if (chunk.length() > 0) result.append(translate(chunk.toString().trim()));
        return result.toString().trim();
    }

    // ────────────────────────────────────────────────────────────────────────
    // 5. FRENCH TTS — Android built-in (offline, female voice if available)
    // ────────────────────────────────────────────────────────────────────────
    private File generateVoice(String text) throws Exception {
        File out = tmp("tts", ".wav");
        CountDownLatch init = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(1);
        String[] err = {null};
        TextToSpeech[] ttsRef = {null};

        new Handler(Looper.getMainLooper()).post(() -> {
            ttsRef[0] = new TextToSpeech(ctx, status -> {
                if (status != TextToSpeech.SUCCESS) { err[0] = "TTS init failed"; init.countDown(); return; }

                TextToSpeech tts = ttsRef[0];
                Locale fr = Locale.FRENCH;
                tts.setLanguage(fr);

                // Prefer female voice
                Voice chosen = null;
                for (Voice v : tts.getVoices()) {
                    if (!v.getLocale().getLanguage().equals("fr")) continue;
                    String n = v.getName().toLowerCase();
                    if (n.contains("female") || n.contains("femme") || n.contains("woman")) {
                        chosen = v; break;
                    }
                    if (chosen == null) chosen = v; // fallback: first FR voice
                }
                if (chosen != null) tts.setVoice(chosen);
                tts.setSpeechRate(0.90f);
                tts.setPitch(1.08f);   // slightly higher = sounds more feminine

                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) {}
                    @Override public void onDone(String id)  { done.countDown(); }
                    @Override public void onError(String id) { err[0] = "TTS error"; done.countDown(); }
                });

                android.os.Bundle p = new android.os.Bundle();
                p.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "dub");
                tts.synthesizeToFile(text, p, out, "dub");
                init.countDown();
            });
        });

        if (!init.await(15, TimeUnit.SECONDS)) throw new Exception("TTS init timeout");
        if (err[0] != null) throw new Exception(err[0]);
        if (!done.await(300, TimeUnit.SECONDS)) throw new Exception("TTS synthesis timeout");
        if (ttsRef[0] != null) ttsRef[0].shutdown();
        if (!out.exists() || out.length() == 0) throw new Exception("Fichier TTS vide");
        return out;
    }

    // ────────────────────────────────────────────────────────────────────────
    // 6. MERGE VIDEO + TTS AUDIO — pure Android MediaMuxer (no ffmpeg needed)
    // ────────────────────────────────────────────────────────────────────────
    private File merge(File video, File ttsAudio) throws Exception {
        File out = tmp("dubbed", ".mp4");

        MediaExtractor vEx = new MediaExtractor();
        MediaExtractor aEx = new MediaExtractor();
        vEx.setDataSource(video.getAbsolutePath());
        aEx.setDataSource(ttsAudio.getAbsolutePath());

        // Find video track
        int vTrack = -1; MediaFormat vFmt = null;
        for (int i = 0; i < vEx.getTrackCount(); i++) {
            MediaFormat f = vEx.getTrackFormat(i);
            if (f.getString(MediaFormat.KEY_MIME).startsWith("video/")) { vTrack = i; vFmt = f; break; }
        }
        if (vTrack < 0) throw new Exception("Aucune piste vidéo");

        // Find audio track from TTS
        int aTrack = -1; MediaFormat aFmt = null;
        for (int i = 0; i < aEx.getTrackCount(); i++) {
            MediaFormat f = aEx.getTrackFormat(i);
            if (f.getString(MediaFormat.KEY_MIME).startsWith("audio/")) { aTrack = i; aFmt = f; break; }
        }

        vEx.selectTrack(vTrack);
        MediaMuxer muxer = new MediaMuxer(out.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        int mVTrack = muxer.addTrack(vFmt);
        int mATrack = -1;
        if (aTrack >= 0) { aEx.selectTrack(aTrack); mATrack = muxer.addTrack(aFmt); }
        muxer.start();

        ByteBuffer buf = ByteBuffer.allocate(2 * 1024 * 1024);
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();

        // Write video samples
        while (true) {
            info.size = vEx.readSampleData(buf, 0);
            if (info.size < 0) break;
            info.presentationTimeUs = vEx.getSampleTime();
            info.flags  = vEx.getSampleFlags();
            info.offset = 0;
            muxer.writeSampleData(mVTrack, buf, info);
            vEx.advance();
        }

        // Write TTS audio samples
        if (mATrack >= 0) {
            while (true) {
                info.size = aEx.readSampleData(buf, 0);
                if (info.size < 0) break;
                info.presentationTimeUs = aEx.getSampleTime();
                info.flags  = aEx.getSampleFlags();
                info.offset = 0;
                muxer.writeSampleData(mATrack, buf, info);
                aEx.advance();
            }
        }

        muxer.stop(); muxer.release();
        vEx.release(); aEx.release();
        return out;
    }

    // ────────────────────────────────────────────────────────────────────────
    // UTILS
    // ────────────────────────────────────────────────────────────────────────
    private void step(int pct, String msg) { cb.onProgress(pct, msg); }

    private File tmp(String pfx, String sfx) {
        return new File(ctx.getCacheDir(), pfx + "_" + System.currentTimeMillis() + sfx);
    }

    private String post(String url, String body, String mime) throws Exception {
        RequestBody rb = RequestBody.create(body, MediaType.parse(mime));
        Request req = new Request.Builder().url(url).post(rb)
            .header("Accept", "application/json").build();
        try (Response resp = http.newCall(req).execute()) {
            if (!resp.isSuccessful()) throw new Exception("HTTP " + resp.code() + " on " + url);
            return resp.body().string();
        }
    }

    private void pipe(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[8192]; int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
    }

    private byte[] readBytes(File f) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        try (FileInputStream fi = new FileInputStream(f)) { pipe(fi, b); }
        return b.toByteArray();
    }

    private void leInt(DataOutputStream d, int v) throws IOException {
        d.write(v&0xFF); d.write((v>>8)&0xFF); d.write((v>>16)&0xFF); d.write((v>>24)&0xFF);
    }
    private void leShort(DataOutputStream d, short v) throws IOException {
        d.write(v&0xFF); d.write((v>>8)&0xFF);
    }
}
